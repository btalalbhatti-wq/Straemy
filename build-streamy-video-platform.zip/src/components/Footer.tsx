export default function Footer() {
  return (
    <footer className="mt-20 border-t border-streamy-border/50 bg-streamy-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-streamy-primary to-streamy-accent flex items-center justify-center font-bold text-sm">
                S
              </div>
              <span className="text-xl font-bold gradient-text">Streamy</span>
            </div>
            <p className="text-sm text-streamy-text-muted max-w-md leading-relaxed">
              Your trusted destination for premium streaming content. We believe in delivering
              value for your time with carefully curated videos across all categories.
            </p>
            <div className="flex items-center gap-1.5 mt-4 text-xs text-streamy-text-muted">
              <span className="w-2 h-2 rounded-full bg-streamy-success animate-pulse" />
              All systems operational
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-sm mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2.5">
              <li>
                <a href="/" className="text-sm text-streamy-text-muted hover:text-streamy-primary-light transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/browse" className="text-sm text-streamy-text-muted hover:text-streamy-primary-light transition-colors">
                  Browse
                </a>
              </li>
              <li>
                <a href="/browse?category=movies" className="text-sm text-streamy-text-muted hover:text-streamy-primary-light transition-colors">
                  Movies
                </a>
              </li>
              <li>
                <a href="/browse?category=music" className="text-sm text-streamy-text-muted hover:text-streamy-primary-light transition-colors">
                  Music
                </a>
              </li>
            </ul>
          </div>

          {/* Trust */}
          <div>
            <h3 className="font-semibold text-sm mb-4 text-white">Why Streamy?</h3>
            <ul className="space-y-2.5">
              <li className="flex items-center gap-2 text-sm text-streamy-text-muted">
                <span className="text-streamy-success">✓</span> Free streaming
              </li>
              <li className="flex items-center gap-2 text-sm text-streamy-text-muted">
                <span className="text-streamy-success">✓</span> No ads interrupting
              </li>
              <li className="flex items-center gap-2 text-sm text-streamy-text-muted">
                <span className="text-streamy-success">✓</span> Smooth playback
              </li>
              <li className="flex items-center gap-2 text-sm text-streamy-text-muted">
                <span className="text-streamy-success">✓</span> Curated content
              </li>
              <li className="flex items-center gap-2 text-sm text-streamy-text-muted">
                <span className="text-streamy-success">✓</span> Privacy focused
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 pt-6 border-t border-streamy-border/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-streamy-text-muted">
            © {new Date().getFullYear()} Streamy. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-streamy-text-muted">
            <span className="flex items-center gap-1">
              🔒 Secure
            </span>
            <span className="flex items-center gap-1">
              🛡️ Trusted
            </span>
            <span className="flex items-center gap-1">
              ⚡ Fast
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
