"use client";

import { useState } from "react";
import Image from "next/image";
import type { Video } from "@/types";

export default function VideoCard({ video, index = 0 }: { video: Video; index?: number }) {
  const [imgError, setImgError] = useState(false);

  const formatViews = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
    if (num >= 1000) return (num / 1000).toFixed(1) + "K";
    return num.toString();
  };

  const timeAgo = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
    if (days < 365) return `${Math.floor(days / 30)} months ago`;
    return `${Math.floor(days / 365)} years ago`;
  };

  return (
    <a
      href={`/watch/${video.id}`}
      className="video-card group block rounded-xl overflow-hidden bg-streamy-card border border-streamy-border/50 animate-fade-in"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        {!imgError ? (
          <Image
            src={video.thumbnailUrl}
            alt={video.title}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-cover group-hover:scale-110 transition-transform duration-500"
            onError={() => setImgError(true)}
            unoptimized
          />
        ) : (
          <div className="w-full h-full bg-streamy-surface flex items-center justify-center">
            <svg className="w-12 h-12 text-streamy-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        )}
        {/* Play overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 scale-75 group-hover:scale-100">
            <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
        {/* Bottom gradient */}
        <div className="thumbnail-overlay absolute bottom-0 left-0 right-0 h-24 pointer-events-none" />
        {/* Category badge */}
        {video.categoryName && (
          <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-streamy-primary/80 text-[10px] font-medium backdrop-blur-sm">
            {video.categoryIcon} {video.categoryName}
          </span>
        )}
        {/* Views */}
        <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-black/60 text-[10px] font-medium backdrop-blur-sm flex items-center gap-1">
          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
          {formatViews(video.views)}
        </span>
      </div>
      {/* Info */}
      <div className="p-3">
        <h3 className="font-semibold text-sm line-clamp-2 group-hover:text-streamy-primary-light transition-colors">
          {video.title}
        </h3>
        <div className="flex items-center gap-2 mt-1.5">
          {video.subcategoryName && (
            <span className="text-[10px] text-streamy-text-muted px-1.5 py-0.5 rounded bg-streamy-surface">
              {video.subcategoryName}
            </span>
          )}
          <span className="text-[10px] text-streamy-text-muted">
            {timeAgo(video.createdAt)}
          </span>
        </div>
      </div>
    </a>
  );
}
