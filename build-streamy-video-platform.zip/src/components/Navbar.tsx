"use client";

import { useState } from "react";
import Link from "next/link";
import DeveloperModal from "./DeveloperModal";
import type { Category } from "@/types";

export default function Navbar({ categories }: { categories: Category[] }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [devModalOpen, setDevModalOpen] = useState(false);
  const [eagleClicks, setEagleClicks] = useState(0);
  const [showPasswordInput, setShowPasswordInput] = useState(false);

  const handleEagleClick = () => {
    const newClicks = eagleClicks + 1;
    setEagleClicks(newClicks);
    if (newClicks >= 3) {
      setShowPasswordInput(true);
    }
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 glass">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-streamy-primary to-streamy-accent flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
                S
              </div>
              <span className="text-xl font-bold gradient-text">Streamy</span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-6">
              <Link href="/" className="text-sm text-streamy-text-muted hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/browse" className="text-sm text-streamy-text-muted hover:text-white transition-colors">
                Browse
              </Link>
              {categories.slice(0, 5).map((cat) => (
                <Link
                  key={cat.id}
                  href={`/browse?category=${cat.slug}`}
                  className="text-sm text-streamy-text-muted hover:text-white transition-colors"
                >
                  {cat.icon} {cat.name}
                </Link>
              ))}
            </div>

            {/* Right side - Eagle emoji & mobile menu */}
            <div className="flex items-center gap-4">
              {/* Hidden developer trigger - Eagle emoji */}
              <button
                onClick={handleEagleClick}
                className="text-xs opacity-30 hover:opacity-50 transition-opacity cursor-default select-none"
                aria-label="eagle"
                title=""
              >
                🦅
              </button>

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-streamy-surface transition-colors"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {mobileMenuOpen ? (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  )}
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden glass border-t border-streamy-border animate-slide-up">
            <div className="px-4 py-3 space-y-2">
              <Link href="/" className="block px-3 py-2 rounded-lg text-sm hover:bg-streamy-surface transition-colors" onClick={() => setMobileMenuOpen(false)}>
                🏠 Home
              </Link>
              <Link href="/browse" className="block px-3 py-2 rounded-lg text-sm hover:bg-streamy-surface transition-colors" onClick={() => setMobileMenuOpen(false)}>
                🔍 Browse All
              </Link>
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/browse?category=${cat.slug}`}
                  className="block px-3 py-2 rounded-lg text-sm hover:bg-streamy-surface transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {cat.icon} {cat.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Developer password input (shown after 3 eagle clicks) */}
      {showPasswordInput && (
        <div className="fixed top-20 right-4 z-[60] animate-scale-in">
          <div className="glass rounded-xl p-4 w-72">
            <h3 className="text-sm font-semibold mb-2 text-streamy-primary-light">🔐 Developer Access</h3>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const password = formData.get("password") as string;
                try {
                  const res = await fetch("/api/auth/developer", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ password }),
                  });
                  const data = await res.json();
                  if (data.success && data.authenticated) {
                    setDevModalOpen(true);
                    setShowPasswordInput(false);
                    setEagleClicks(0);
                  } else {
                    alert("Invalid password!");
                  }
                } catch {
                  alert("Authentication failed");
                }
              }}
            >
              <input
                type="password"
                name="password"
                placeholder="Enter developer password"
                className="w-full bg-streamy-bg border border-streamy-border rounded-lg px-3 py-2 text-sm text-white placeholder-streamy-text-muted mb-2"
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-streamy-primary to-streamy-accent rounded-lg px-3 py-1.5 text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  Unlock
                </button>
                <button
                  type="button"
                  onClick={() => { setShowPasswordInput(false); setEagleClicks(0); }}
                  className="px-3 py-1.5 text-sm text-streamy-text-muted hover:text-white transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Developer Modal */}
      <DeveloperModal isOpen={devModalOpen} onClose={() => setDevModalOpen(false)} categories={categories} />
    </>
  );
}
