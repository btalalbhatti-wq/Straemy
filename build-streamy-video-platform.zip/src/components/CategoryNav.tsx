"use client";

import Link from "next/link";
import type { Category } from "@/types";

interface CategoryNavProps {
  categories: Category[];
  activeCategory?: string;
  activeSubcategory?: string;
}

export default function CategoryNav({ categories, activeCategory, activeSubcategory }: CategoryNavProps) {
  return (
    <div className="mb-8">
      {/* Category pills */}
      <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-3">
        <Link
          href="/browse"
          className={`category-pill flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition-all ${
            !activeCategory
              ? "active text-white"
              : "border-streamy-border text-streamy-text-muted"
          }`}
        >
          🔥 All
        </Link>
        {categories.map((cat) => (
          <Link
            key={cat.id}
            href={`/browse?category=${cat.slug}`}
            className={`category-pill flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition-all ${
              activeCategory === cat.slug
                ? "active text-white"
                : "border-streamy-border text-streamy-text-muted"
            }`}
          >
            {cat.icon} {cat.name}
          </Link>
        ))}
      </div>

      {/* Subcategories */}
      {activeCategory && categories.find((c) => c.slug === activeCategory)?.subcategories && (
        <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-2 mt-3">
          {categories
            .find((c) => c.slug === activeCategory)
            ?.subcategories?.map((sub) => (
              <Link
                key={sub.id}
                href={`/browse?category=${activeCategory}&subcategory=${sub.slug}`}
                className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                  activeSubcategory === sub.slug
                    ? "bg-streamy-primary/30 border-streamy-primary/50 text-streamy-primary-light"
                    : "bg-streamy-surface/50 border-streamy-border/50 text-streamy-text-muted hover:text-white hover:border-streamy-border"
                }`}
              >
                {sub.name}
              </Link>
            ))}
        </div>
      )}
    </div>
  );
}
