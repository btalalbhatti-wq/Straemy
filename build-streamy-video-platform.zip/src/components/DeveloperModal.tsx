"use client";

import { useState, useEffect } from "react";
import type { Category } from "@/types";

interface DeveloperModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
}

export default function DeveloperModal({ isOpen, onClose, categories }: DeveloperModalProps) {
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState("");
  const [description, setDescription] = useState("");
  const [dailymotionId, setDailymotionId] = useState("");
  const [categoryId, setCategoryId] = useState<number | null>(null);
  const [subcategoryId, setSubcategoryId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [fetchingInfo, setFetchingInfo] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [availableSubcategories, setAvailableSubcategories] = useState<{ id: number; name: string; slug: string }[]>([]);

  useEffect(() => {
    if (categoryId) {
      const cat = categories.find((c) => c.id === categoryId);
      setAvailableSubcategories(cat?.subcategories || []);
    } else {
      setAvailableSubcategories([]);
    }
    setSubcategoryId(null);
  }, [categoryId, categories]);

  const fetchVideoInfo = async () => {
    if (!url.trim()) return;
    setFetchingInfo(true);
    setError("");
    try {
      const res = await fetch(`/api/dailymotion/info?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      if (data.success) {
        setTitle(data.title);
        setThumbnailUrl(data.thumbnail);
        setDailymotionId(data.videoId);
        setDescription(data.description || "");
      } else {
        setError(data.message || "Failed to fetch video info");
      }
    } catch {
      setError("Failed to fetch video info. Check the URL and try again.");
    } finally {
      setFetchingInfo(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dailymotionId || !title || !thumbnailUrl) {
      setError("Please fetch video info first");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/videos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dailymotionId,
          title,
          thumbnailUrl,
          dailymotionUrl: url,
          categoryId,
          subcategoryId,
          description,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccess(true);
        setTimeout(() => {
          setUrl("");
          setTitle("");
          setThumbnailUrl("");
          setDescription("");
          setDailymotionId("");
          setCategoryId(null);
          setSubcategoryId(null);
          setSuccess(false);
        }, 2000);
      } else {
        setError(data.message || "Failed to add video");
      }
    } catch {
      setError("Failed to add video. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] modal-overlay flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-streamy-card rounded-2xl border border-streamy-border w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-streamy-border">
          <div>
            <h2 className="text-lg font-bold gradient-text">🛡️ Developer Panel</h2>
            <p className="text-xs text-streamy-text-muted mt-0.5">Add videos to Streamy</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-streamy-surface transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Success message */}
          {success && (
            <div className="bg-streamy-success/20 border border-streamy-success/30 rounded-xl p-3 text-sm text-streamy-success flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Video added successfully!
            </div>
          )}

          {/* Error message */}
          {error && (
            <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-3 text-sm text-red-400 flex items-center gap-2">
              <svg className="w-5 h-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}

          {/* Dailymotion URL */}
          <div>
            <label className="block text-sm font-medium mb-1.5 text-streamy-text-muted">
              Dailymotion Video URL
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://www.dailymotion.com/video/..."
                className="flex-1 bg-streamy-bg border border-streamy-border rounded-xl px-4 py-2.5 text-sm text-white placeholder-streamy-text-muted"
                required
              />
              <button
                type="button"
                onClick={fetchVideoInfo}
                disabled={fetchingInfo || !url.trim()}
                className="px-4 py-2.5 bg-streamy-primary hover:bg-streamy-primary-light rounded-xl text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {fetchingInfo ? (
                  <>
                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Fetching
                  </>
                ) : (
                  "Fetch"
                )}
              </button>
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-medium mb-1.5 text-streamy-text-muted">
              Video Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Video title (auto-fetched)"
              className="w-full bg-streamy-bg border border-streamy-border rounded-xl px-4 py-2.5 text-sm text-white placeholder-streamy-text-muted"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium mb-1.5 text-streamy-text-muted">
              Description (optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a description for this video"
              rows={2}
              className="w-full bg-streamy-bg border border-streamy-border rounded-xl px-4 py-2.5 text-sm text-white placeholder-streamy-text-muted resize-none"
            />
          </div>

          {/* Thumbnail preview */}
          {thumbnailUrl && (
            <div>
              <label className="block text-sm font-medium mb-1.5 text-streamy-text-muted">
                Thumbnail Preview
              </label>
              <div className="relative aspect-video rounded-xl overflow-hidden border border-streamy-border">
                <img
                  src={thumbnailUrl}
                  alt="Thumbnail preview"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-streamy-success/80 text-[10px] font-medium backdrop-blur-sm">
                  ✓ Auto-fetched
                </div>
              </div>
            </div>
          )}

          {/* Category */}
          <div>
            <label className="block text-sm font-medium mb-1.5 text-streamy-text-muted">
              Category
            </label>
            <select
              value={categoryId || ""}
              onChange={(e) => setCategoryId(e.target.value ? Number(e.target.value) : null)}
              className="w-full bg-streamy-bg border border-streamy-border rounded-xl px-4 py-2.5 text-sm text-white appearance-none cursor-pointer"
            >
              <option value="">Select a category</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.icon} {cat.name}
                </option>
              ))}
            </select>
          </div>

          {/* Subcategory */}
          {availableSubcategories.length > 0 && (
            <div>
              <label className="block text-sm font-medium mb-1.5 text-streamy-text-muted">
                Subcategory
              </label>
              <div className="flex flex-wrap gap-2">
                {availableSubcategories.map((sub) => (
                  <button
                    key={sub.id}
                    type="button"
                    onClick={() => setSubcategoryId(sub.id === subcategoryId ? null : sub.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      subcategoryId === sub.id
                        ? "bg-streamy-primary border-streamy-primary text-white"
                        : "bg-streamy-bg border-streamy-border text-streamy-text-muted hover:border-streamy-primary/50"
                    }`}
                  >
                    {sub.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={loading || !dailymotionId}
            className="w-full py-3 bg-gradient-to-r from-streamy-primary to-streamy-accent rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Adding Video...
              </>
            ) : (
              "🚀 Add Video to Streamy"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
