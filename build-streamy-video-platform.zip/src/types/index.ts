export interface Subcategory {
  id: number;
  name: string;
  slug: string;
  categoryId: number;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  icon: string;
  displayOrder: number;
  subcategories: Subcategory[];
}

export interface Video {
  id: number;
  dailymotionId: string;
  title: string;
  description: string | null;
  thumbnailUrl: string;
  dailymotionUrl: string;
  categoryId: number | null;
  subcategoryId: number | null;
  views: number;
  createdAt: string;
  categoryName: string | null;
  categorySlug: string | null;
  categoryIcon: string | null;
  subcategoryName: string | null;
  subcategorySlug: string | null;
}
