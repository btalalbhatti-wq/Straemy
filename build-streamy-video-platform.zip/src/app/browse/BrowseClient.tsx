"use client";

import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import VideoCard from "@/components/VideoCard";
import CategoryNav from "@/components/CategoryNav";
import Footer from "@/components/Footer";
import type { Video, Category } from "@/types";

export default function BrowseClient({ categories }: { categories: Category[] }) {
  const searchParams = useSearchParams();
  const activeCategory = searchParams.get("category") || undefined;
  const activeSubcategory = searchParams.get("subcategory") || undefined;

  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const limit = 20;

  const fetchVideos = useCallback(async (newOffset = 0) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        offset: newOffset.toString(),
      });
      if (activeCategory) params.set("category", activeCategory);
      if (activeSubcategory) params.set("subcategory", activeSubcategory);

      const res = await fetch(`/api/videos?${params}`);
      const data = await res.json();
      if (data.success) {
        if (newOffset === 0) {
          setVideos(data.videos);
        } else {
          setVideos((prev) => [...prev, ...data.videos]);
        }
        setTotal(data.total);
        setOffset(newOffset);
      }
    } catch {
      console.error("Failed to fetch videos");
    } finally {
      setLoading(false);
    }
  }, [activeCategory, activeSubcategory]);

  useEffect(() => {
    fetchVideos(0);
  }, [fetchVideos]);

  const loadMore = () => {
    fetchVideos(offset + limit);
  };

  const currentCategory = categories.find((c) => c.slug === activeCategory);

  return (
    <div className="min-h-screen">
      <Navbar categories={categories} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        {/* Page header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {currentCategory ? (
              <>
                {currentCategory.icon} {currentCategory.name}
              </>
            ) : (
              <>🔍 Browse All Videos</>
            )}
          </h1>
          <p className="text-streamy-text-muted text-sm">
            {currentCategory
              ? `Explore the best ${currentCategory.name.toLowerCase()} content on Streamy`
              : "Discover amazing content across all categories"}
          </p>
        </div>

        {/* Category navigation */}
        <CategoryNav
          categories={categories}
          activeCategory={activeCategory}
          activeSubcategory={activeSubcategory}
        />

        {/* Results info */}
        <div className="flex items-center justify-between mb-6">
          <span className="text-sm text-streamy-text-muted">
            {total} video{total !== 1 ? "s" : ""} found
          </span>
        </div>

        {/* Videos grid */}
        {videos.length > 0 ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {videos.map((video, i) => (
                <VideoCard key={video.id} video={video} index={i} />
              ))}
            </div>

            {/* Load more */}
            {videos.length < total && (
              <div className="flex justify-center mt-10">
                <button
                  onClick={loadMore}
                  disabled={loading}
                  className="px-8 py-3 bg-streamy-surface border border-streamy-border rounded-xl font-medium text-sm hover:bg-streamy-card hover:border-streamy-primary/50 transition-all disabled:opacity-50"
                >
                  {loading ? "Loading..." : "Load More Videos"}
                </button>
              </div>
            )}
          </>
        ) : loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="flex items-center gap-3 text-streamy-text-muted">
              <svg className="w-6 h-6 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Loading videos...
            </div>
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">📭</div>
            <h2 className="text-xl font-bold mb-2">No Videos Found</h2>
            <p className="text-streamy-text-muted max-w-md mx-auto">
              {activeCategory
                ? `No videos found in this category yet. Check back soon!`
                : "No videos available yet. Be the first to add content!"}
            </p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
