export default function BrowseLoading() {
  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* Nav skeleton */}
      <div className="fixed top-0 left-0 right-0 z-50 glass">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="w-24 h-6 bg-streamy-surface rounded animate-shimmer" />
          <div className="hidden md:flex gap-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="w-16 h-4 bg-streamy-surface rounded animate-shimmer" />
            ))}
          </div>
        </div>
      </div>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        {/* Header skeleton */}
        <div className="mb-8">
          <div className="w-48 h-8 bg-streamy-surface rounded animate-shimmer mb-2" />
          <div className="w-72 h-4 bg-streamy-surface rounded animate-shimmer" />
        </div>
        
        {/* Grid skeleton */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="rounded-xl overflow-hidden bg-streamy-card border border-streamy-border/50">
              <div className="aspect-video bg-streamy-surface animate-shimmer" />
              <div className="p-3 space-y-2">
                <div className="w-3/4 h-4 bg-streamy-surface rounded animate-shimmer" />
                <div className="w-1/2 h-3 bg-streamy-surface rounded animate-shimmer" />
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
