import { db } from "@/db";
import { categories, subcategories } from "@/db/schema";
import { eq } from "drizzle-orm";
import BrowseClient from "./BrowseClient";
import type { Category } from "@/types";
import { Suspense } from "react";

async function getData() {
  try {
    const allCategories = await db
      .select()
      .from(categories)
      .orderBy(categories.displayOrder);

    const allSubcategories = await db.select().from(subcategories);

    const categoriesWithSubs: Category[] = allCategories.map((cat) => ({
      ...cat,
      subcategories: allSubcategories.filter((sub) => sub.categoryId === cat.id),
    }));

    return { categories: categoriesWithSubs };
  } catch (error) {
    console.error("Browse data fetch error:", error);
    return { categories: [] };
  }
}

export default async function BrowsePage() {
  const { categories } = await getData();

  return (
    <Suspense fallback={
      <div className="min-h-screen bg-streamy-bg flex items-center justify-center">
        <div className="flex items-center gap-3 text-streamy-text-muted">
          <svg className="w-6 h-6 animate-spin" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          Loading...
        </div>
      </div>
    }>
      <BrowseClient categories={categories} />
    </Suspense>
  );
}
