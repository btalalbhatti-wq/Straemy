"use client";

import { useState } from "react";
import Navbar from "@/components/Navbar";
import VideoCard from "@/components/VideoCard";
import Footer from "@/components/Footer";
import type { Video, Category } from "@/types";

interface HomeClientProps {
  categories: Category[];
  recentVideos: Video[];
  videosByCategory: Record<string, Video[]>;
}

export default function HomeClient({ categories, recentVideos, videosByCategory }: HomeClientProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Video[]>([]);
  const [searching, setSearching] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const res = await fetch(`/api/videos?search=${encodeURIComponent(searchQuery)}&limit=20`);
      const data = await res.json();
      if (data.success) {
        setSearchResults(data.videos);
      }
    } catch {
      console.error("Search failed");
    } finally {
      setSearching(false);
    }
  };

  const featuredVideo = recentVideos[0];

  return (
    <div className="min-h-screen">
      <Navbar categories={categories} />

      {/* Hero Section */}
      <section className="hero-gradient pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-10 py-10">
            {/* Left content */}
            <div className="flex-1 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-streamy-primary/20 border border-streamy-primary/30 text-streamy-primary-light text-xs font-medium mb-4 animate-fade-in">
                <span className="w-1.5 h-1.5 rounded-full bg-streamy-success animate-pulse" />
                Live Streaming Platform
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight mb-4 animate-slide-up">
                Stream{" "}
                <span className="gradient-text">Unlimited</span>
                <br />
                Entertainment
              </h1>
              <p className="text-streamy-text-muted text-lg max-w-lg mb-6 animate-slide-up" style={{ animationDelay: "0.1s" }}>
                Your trusted destination for premium content. Curated videos across
                movies, music, gaming, sports, and more. Value for your time, always.
              </p>

              {/* Search bar */}
              <form onSubmit={handleSearch} className="flex gap-2 max-w-md mx-auto lg:mx-0 animate-slide-up" style={{ animationDelay: "0.2s" }}>
                <div className="flex-1 relative">
                  <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-streamy-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search videos..."
                    className="w-full bg-streamy-card border border-streamy-border rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-streamy-text-muted"
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-3 bg-gradient-to-r from-streamy-primary to-streamy-accent rounded-xl text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  Search
                </button>
              </form>

              {/* Trust badges */}
              <div className="flex items-center justify-center lg:justify-start gap-4 mt-6 animate-fade-in" style={{ animationDelay: "0.3s" }}>
                <div className="flex items-center gap-1.5 text-xs text-streamy-text-muted">
                  <span className="text-streamy-success">✓</span> Free Forever
                </div>
                <div className="flex items-center gap-1.5 text-xs text-streamy-text-muted">
                  <span className="text-streamy-success">✓</span> No Ads
                </div>
                <div className="flex items-center gap-1.5 text-xs text-streamy-text-muted">
                  <span className="text-streamy-success">✓</span> HD Quality
                </div>
              </div>
            </div>

            {/* Right - Featured video preview */}
            {featuredVideo && (
              <div className="flex-1 max-w-lg w-full animate-slide-up" style={{ animationDelay: "0.2s" }}>
                <a href={`/watch/${featuredVideo.id}`} className="block group">
                  <div className="relative aspect-video rounded-2xl overflow-hidden border border-streamy-border/50 shadow-2xl shadow-streamy-primary/10">
                    <img
                      src={featuredVideo.thumbnailUrl}
                      alt={featuredVideo.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:scale-110 transition-transform animate-pulse-glow">
                        <svg className="w-7 h-7 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z" />
                        </svg>
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <span className="text-xs font-medium text-streamy-primary-light mb-1 block">
                        🔥 Featured
                      </span>
                      <h3 className="font-bold text-sm text-white line-clamp-2">
                        {featuredVideo.title}
                      </h3>
                    </div>
                  </div>
                </a>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Results */}
        {searching && (
          <div className="flex items-center justify-center py-20">
            <div className="flex items-center gap-3 text-streamy-text-muted">
              <svg className="w-6 h-6 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Searching...
            </div>
          </div>
        )}

        {searchResults.length > 0 && !searching && (
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                🔍 Search Results
                <span className="text-sm font-normal text-streamy-text-muted">
                  ({searchResults.length} found)
                </span>
              </h2>
              <button
                onClick={() => { setSearchResults([]); setSearchQuery(""); }}
                className="text-sm text-streamy-primary-light hover:underline"
              >
                Clear search
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {searchResults.map((video, i) => (
                <VideoCard key={video.id} video={video} index={i} />
              ))}
            </div>
          </section>
        )}

        {/* Recent Videos */}
        {recentVideos.length > 0 && searchResults.length === 0 && (
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                🔥 Trending Now
              </h2>
              <a href="/browse" className="text-sm text-streamy-primary-light hover:underline">
                View all →
              </a>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {recentVideos.slice(0, 8).map((video, i) => (
                <VideoCard key={video.id} video={video} index={i} />
              ))}
            </div>
          </section>
        )}

        {/* Videos by Category */}
        {searchResults.length === 0 &&
          Object.entries(videosByCategory).map(([catSlug, catVideos]) => {
            const cat = categories.find((c) => c.slug === catSlug);
            if (!cat || catVideos.length === 0) return null;
            return (
              <section key={catSlug} className="mb-12">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    {cat.icon} {cat.name}
                  </h2>
                  <a
                    href={`/browse?category=${cat.slug}`}
                    className="text-sm text-streamy-primary-light hover:underline"
                  >
                    View all →
                  </a>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {catVideos.slice(0, 4).map((video, i) => (
                    <VideoCard key={video.id} video={video} index={i} />
                  ))}
                </div>
              </section>
            );
          })}

        {/* Categories Grid */}
        {searchResults.length === 0 && (
          <section className="mb-12">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              📂 Explore Categories
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {categories.map((cat, i) => (
                <a
                  key={cat.id}
                  href={`/browse?category=${cat.slug}`}
                  className="group p-4 rounded-xl bg-streamy-card border border-streamy-border/50 hover:border-streamy-primary/50 transition-all hover:scale-[1.03] animate-fade-in"
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <span className="text-2xl block mb-2 group-hover:scale-125 transition-transform">
                    {cat.icon}
                  </span>
                  <span className="text-sm font-medium group-hover:text-streamy-primary-light transition-colors">
                    {cat.name}
                  </span>
                  {cat.subcategories && cat.subcategories.length > 0 && (
                    <span className="text-[10px] text-streamy-text-muted block mt-1">
                      {cat.subcategories.length} subcategories
                    </span>
                  )}
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Empty state */}
        {recentVideos.length === 0 && searchResults.length === 0 && (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🎬</div>
            <h2 className="text-2xl font-bold mb-2">No Videos Yet</h2>
            <p className="text-streamy-text-muted max-w-md mx-auto">
              Streamy is just getting started! Check back soon for amazing content across all categories.
            </p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
