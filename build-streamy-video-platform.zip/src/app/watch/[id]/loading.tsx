export default function WatchLoading() {
  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <div className="lg:flex gap-8">
          <div className="flex-1 min-w-0">
            {/* Player skeleton */}
            <div className="aspect-video bg-streamy-surface rounded-xl animate-shimmer mb-6" />
            {/* Info skeleton */}
            <div className="space-y-3 mb-4">
              <div className="w-3/4 h-7 bg-streamy-surface rounded animate-shimmer" />
              <div className="flex gap-3">
                <div className="w-20 h-5 bg-streamy-surface rounded animate-shimmer" />
                <div className="w-24 h-5 bg-streamy-surface rounded animate-shimmer" />
              </div>
            </div>
            <div className="flex gap-3 mb-6">
              <div className="w-40 h-10 bg-streamy-surface rounded-xl animate-shimmer" />
              <div className="w-24 h-10 bg-streamy-surface rounded-xl animate-shimmer" />
            </div>
          </div>
          <div className="lg:w-80 xl:w-96 flex-shrink-0 mt-8 lg:mt-0">
            <div className="w-36 h-6 bg-streamy-surface rounded animate-shimmer mb-4" />
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="rounded-xl overflow-hidden bg-streamy-card border border-streamy-border/50">
                  <div className="aspect-video bg-streamy-surface animate-shimmer" />
                  <div className="p-3 space-y-2">
                    <div className="w-3/4 h-4 bg-streamy-surface rounded animate-shimmer" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
