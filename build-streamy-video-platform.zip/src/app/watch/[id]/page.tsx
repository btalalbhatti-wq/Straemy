import { db } from "@/db";
import { categories, subcategories, videos } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import WatchClient from "./WatchClient";
import type { Category, Video } from "@/types";
import { notFound } from "next/navigation";

async function getData(videoId: number) {
  try {
    const videoResult = await db
      .select({
        id: videos.id,
        dailymotionId: videos.dailymotionId,
        title: videos.title,
        description: videos.description,
        thumbnailUrl: videos.thumbnailUrl,
        dailymotionUrl: videos.dailymotionUrl,
        categoryId: videos.categoryId,
        subcategoryId: videos.subcategoryId,
        views: videos.views,
        createdAt: videos.createdAt,
        categoryName: categories.name,
        categorySlug: categories.slug,
        categoryIcon: categories.icon,
        subcategoryName: subcategories.name,
        subcategorySlug: subcategories.slug,
      })
      .from(videos)
      .leftJoin(categories, eq(videos.categoryId, categories.id))
      .leftJoin(subcategories, eq(videos.subcategoryId, subcategories.id))
      .where(eq(videos.id, videoId))
      .limit(1);

    if (videoResult.length === 0) return null;

    const video: Video = {
      ...videoResult[0],
      createdAt:
        videoResult[0].createdAt instanceof Date
          ? videoResult[0].createdAt.toISOString()
          : String(videoResult[0].createdAt ?? ""),
    };

    // Get related videos (same category, excluding current)
    const relatedVideosRaw = video.categoryId
      ? await db
          .select({
            id: videos.id,
            dailymotionId: videos.dailymotionId,
            title: videos.title,
            description: videos.description,
            thumbnailUrl: videos.thumbnailUrl,
            dailymotionUrl: videos.dailymotionUrl,
            categoryId: videos.categoryId,
            subcategoryId: videos.subcategoryId,
            views: videos.views,
            createdAt: videos.createdAt,
            categoryName: categories.name,
            categorySlug: categories.slug,
            categoryIcon: categories.icon,
            subcategoryName: subcategories.name,
            subcategorySlug: subcategories.slug,
          })
          .from(videos)
          .leftJoin(categories, eq(videos.categoryId, categories.id))
          .leftJoin(subcategories, eq(videos.subcategoryId, subcategories.id))
          .where(eq(videos.categoryId, video.categoryId!))
          .orderBy(desc(videos.createdAt))
          .limit(8)
      : [];

    const relatedVideos: Video[] = relatedVideosRaw
      .filter((v) => v.id !== videoId)
      .map((v) => ({
        ...v,
        createdAt:
          v.createdAt instanceof Date
            ? v.createdAt.toISOString()
            : String(v.createdAt ?? ""),
      }));

    // Get all categories
    const allCategories = await db
      .select()
      .from(categories)
      .orderBy(categories.displayOrder);

    const allSubcategories = await db.select().from(subcategories);

    const categoriesWithSubs: Category[] = allCategories.map((cat) => ({
      ...cat,
      subcategories: allSubcategories.filter((sub) => sub.categoryId === cat.id),
    }));

    return { video, relatedVideos, categories: categoriesWithSubs };
  } catch (error) {
    console.error("Watch data fetch error:", error);
    return null;
  }
}

export default async function WatchPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const videoId = parseInt(id);

  if (isNaN(videoId)) {
    notFound();
  }

  const data = await getData(videoId);

  if (!data) {
    notFound();
  }

  return <WatchClient video={data.video} relatedVideos={data.relatedVideos} categories={data.categories} />;
}
