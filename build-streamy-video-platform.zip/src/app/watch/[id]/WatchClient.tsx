"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import VideoCard from "@/components/VideoCard";
import Footer from "@/components/Footer";
import type { Video, Category } from "@/types";

export default function WatchClient({
  video,
  relatedVideos,
  categories,
}: {
  video: Video;
  relatedVideos: Video[];
  categories: Category[];
}) {
  const [viewsUpdated, setViewsUpdated] = useState(false);

  useEffect(() => {
    // Increment view count
    if (!viewsUpdated) {
      fetch(`/api/videos/${video.id}/views`, { method: "POST" }).catch(() => {});
      setViewsUpdated(true);
    }
  }, [video.id, viewsUpdated]);

  const formatViews = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
    if (num >= 1000) return (num / 1000).toFixed(1) + "K";
    return num.toString();
  };

  const timeAgo = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
    if (days < 365) return `${Math.floor(days / 30)} months ago`;
    return `${Math.floor(days / 365)} years ago`;
  };

  return (
    <div className="min-h-screen">
      <Navbar categories={categories} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <div className="lg:flex gap-8">
          {/* Video Player & Info */}
          <div className="flex-1 min-w-0">
            {/* Dailymotion Embed */}
            <div className="dm-embed-container shadow-2xl shadow-streamy-primary/10 mb-6 animate-fade-in">
              <iframe
                src={`https://www.dailymotion.com/embed/video/${video.dailymotionId}?autoplay=1&ui-logo=0&ui-start-screen-info=0`}
                allow="autoplay; fullscreen; picture-in-picture"
                allowFullScreen
                title={video.title}
              />
            </div>

            {/* Video Info */}
            <div className="animate-slide-up">
              <h1 className="text-xl sm:text-2xl font-bold mb-3 line-clamp-2">
                {video.title}
              </h1>

              <div className="flex flex-wrap items-center gap-3 mb-4 text-sm text-streamy-text-muted">
                <span className="flex items-center gap-1.5">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  {formatViews(video.views + 1)} views
                </span>
                <span className="flex items-center gap-1.5">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {timeAgo(video.createdAt)}
                </span>
                {video.categoryName && (
                  <a
                    href={`/browse?category=${video.categorySlug}`}
                    className="px-2.5 py-1 rounded-lg bg-streamy-primary/20 text-streamy-primary-light text-xs font-medium hover:bg-streamy-primary/30 transition-colors"
                  >
                    {video.categoryIcon} {video.categoryName}
                  </a>
                )}
                {video.subcategoryName && (
                  <a
                    href={`/browse?category=${video.categorySlug}&subcategory=${video.subcategorySlug}`}
                    className="px-2.5 py-1 rounded-lg bg-streamy-surface text-streamy-text-muted text-xs font-medium hover:text-white transition-colors"
                  >
                    {video.subcategoryName}
                  </a>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 mb-6">
                <a
                  href={video.dailymotionUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-streamy-surface border border-streamy-border rounded-xl text-sm hover:bg-streamy-card transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                  Watch on Dailymotion
                </a>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-streamy-surface border border-streamy-border rounded-xl text-sm hover:bg-streamy-card transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                  </svg>
                  Share
                </button>
              </div>

              {/* Description */}
              {video.description && (
                <div className="p-4 bg-streamy-card rounded-xl border border-streamy-border/50 mb-6">
                  <h3 className="text-sm font-semibold mb-2 text-streamy-text-muted">Description</h3>
                  <p className="text-sm text-streamy-text leading-relaxed whitespace-pre-line">
                    {video.description}
                  </p>
                </div>
              )}

              {/* Trust indicator */}
              <div className="flex items-center gap-4 p-4 bg-streamy-card/50 rounded-xl border border-streamy-success/20 mb-6">
                <div className="flex items-center gap-2">
                  <span className="text-streamy-success text-lg">🛡️</span>
                  <div>
                    <p className="text-xs font-medium text-streamy-success">Verified Content</p>
                    <p className="text-[10px] text-streamy-text-muted">This video has been curated by Streamy</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Related Videos */}
          <div className="lg:w-80 xl:w-96 flex-shrink-0 mt-8 lg:mt-0">
            <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
              📺 Related Videos
            </h2>
            {relatedVideos.length > 0 ? (
              <div className="space-y-3">
                {relatedVideos.map((rv, i) => (
                  <VideoCard key={rv.id} video={rv} index={i} />
                ))}
              </div>
            ) : (
              <div className="text-center py-10 bg-streamy-card rounded-xl border border-streamy-border/50">
                <p className="text-sm text-streamy-text-muted">No related videos found</p>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
