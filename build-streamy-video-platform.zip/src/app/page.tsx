import { db } from "@/db";
import { categories, subcategories, videos } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import HomeClient from "./HomeClient";
import type { Video, Category } from "@/types";

async function getData() {
  try {
    const allCategories = await db
      .select()
      .from(categories)
      .orderBy(categories.displayOrder);

    const allSubcategories = await db.select().from(subcategories);

    const categoriesWithSubs: Category[] = allCategories.map((cat) => ({
      ...cat,
      subcategories: allSubcategories.filter((sub) => sub.categoryId === cat.id),
    }));

    const recentVideosRaw = await db
      .select({
        id: videos.id,
        dailymotionId: videos.dailymotionId,
        title: videos.title,
        description: videos.description,
        thumbnailUrl: videos.thumbnailUrl,
        dailymotionUrl: videos.dailymotionUrl,
        categoryId: videos.categoryId,
        subcategoryId: videos.subcategoryId,
        views: videos.views,
        createdAt: videos.createdAt,
        categoryName: categories.name,
        categorySlug: categories.slug,
        categoryIcon: categories.icon,
        subcategoryName: subcategories.name,
        subcategorySlug: subcategories.slug,
      })
      .from(videos)
      .leftJoin(categories, eq(videos.categoryId, categories.id))
      .leftJoin(subcategories, eq(videos.subcategoryId, subcategories.id))
      .orderBy(desc(videos.createdAt))
      .limit(20);

    const recentVideos: Video[] = recentVideosRaw.map((v) => ({
      ...v,
      createdAt: v.createdAt instanceof Date ? v.createdAt.toISOString() : String(v.createdAt ?? ""),
    }));

    // Group videos by category
    const videosByCategory: Record<string, Video[]> = {};
    for (const video of recentVideos) {
      const catSlug = video.categorySlug || "uncategorized";
      if (!videosByCategory[catSlug]) {
        videosByCategory[catSlug] = [];
      }
      videosByCategory[catSlug].push(video);
    }

    return { categories: categoriesWithSubs, recentVideos, videosByCategory };
  } catch (error) {
    console.error("Home data fetch error:", error);
    return { categories: [], recentVideos: [], videosByCategory: {} };
  }
}

export default async function HomePage() {
  const { categories, recentVideos, videosByCategory } = await getData();

  return (
    <HomeClient
      categories={categories}
      recentVideos={recentVideos}
      videosByCategory={videosByCategory}
    />
  );
}
