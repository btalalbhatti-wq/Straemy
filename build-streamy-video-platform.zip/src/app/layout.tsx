import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Streamy - Premium Streaming Platform",
  description: "Your trusted destination for premium streaming content. Watch movies, TV shows, music, gaming, and more on Streamy.",
  keywords: "streaming, movies, TV shows, music, gaming, videos, entertainment",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#0a0a0f] text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
