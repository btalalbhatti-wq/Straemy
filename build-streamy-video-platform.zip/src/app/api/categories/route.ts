import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories, subcategories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const allCategories = await db
      .select()
      .from(categories)
      .orderBy(categories.displayOrder);

    const allSubcategories = await db
      .select()
      .from(subcategories);

    const result = allCategories.map((cat) => ({
      ...cat,
      subcategories: allSubcategories.filter(
        (sub) => sub.categoryId === cat.id
      ),
    }));

    return NextResponse.json({ success: true, categories: result });
  } catch (error) {
    console.error("Categories fetch error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to fetch categories" },
      { status: 500 }
    );
  }
}
