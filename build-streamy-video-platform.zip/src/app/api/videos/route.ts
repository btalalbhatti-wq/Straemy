import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos, categories, subcategories } from "@/db/schema";
import { eq, desc, sql, and } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const categorySlug = searchParams.get("category");
    const subcategorySlug = searchParams.get("subcategory");
    const search = searchParams.get("search");
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");

    let query = db
      .select({
        id: videos.id,
        dailymotionId: videos.dailymotionId,
        title: videos.title,
        description: videos.description,
        thumbnailUrl: videos.thumbnailUrl,
        dailymotionUrl: videos.dailymotionUrl,
        categoryId: videos.categoryId,
        subcategoryId: videos.subcategoryId,
        views: videos.views,
        createdAt: videos.createdAt,
        categoryName: categories.name,
        categorySlug: categories.slug,
        categoryIcon: categories.icon,
        subcategoryName: subcategories.name,
        subcategorySlug: subcategories.slug,
      })
      .from(videos)
      .leftJoin(categories, eq(videos.categoryId, categories.id))
      .leftJoin(subcategories, eq(videos.subcategoryId, subcategories.id))
      .orderBy(desc(videos.createdAt))
      .limit(limit)
      .offset(offset);

    const conditions = [];

    if (categorySlug) {
      const categoryResult = await db
        .select({ id: categories.id })
        .from(categories)
        .where(eq(categories.slug, categorySlug))
        .limit(1);

      if (categoryResult.length > 0) {
        conditions.push(eq(videos.categoryId, categoryResult[0].id));
      }
    }

    if (subcategorySlug) {
      const subcategoryResult = await db
        .select({ id: subcategories.id })
        .from(subcategories)
        .where(eq(subcategories.slug, subcategorySlug))
        .limit(1);

      if (subcategoryResult.length > 0) {
        conditions.push(eq(videos.subcategoryId, subcategoryResult[0].id));
      }
    }

    if (search) {
      conditions.push(sql`${videos.title} ILIKE ${"%" + search + "%"}`);
    }

    let result;
    if (conditions.length > 0) {
      result = await db
        .select({
          id: videos.id,
          dailymotionId: videos.dailymotionId,
          title: videos.title,
          description: videos.description,
          thumbnailUrl: videos.thumbnailUrl,
          dailymotionUrl: videos.dailymotionUrl,
          categoryId: videos.categoryId,
          subcategoryId: videos.subcategoryId,
          views: videos.views,
          createdAt: videos.createdAt,
          categoryName: categories.name,
          categorySlug: categories.slug,
          categoryIcon: categories.icon,
          subcategoryName: subcategories.name,
          subcategorySlug: subcategories.slug,
        })
        .from(videos)
        .leftJoin(categories, eq(videos.categoryId, categories.id))
        .leftJoin(subcategories, eq(videos.subcategoryId, subcategories.id))
        .where(and(...conditions))
        .orderBy(desc(videos.createdAt))
        .limit(limit)
        .offset(offset);
    } else {
      result = await query;
    }

    // Get total count
    const countResult = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(videos);

    return NextResponse.json({
      success: true,
      videos: result,
      total: countResult[0]?.count || 0,
    });
  } catch (error) {
    console.error("Videos fetch error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to fetch videos" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { dailymotionId, title, thumbnailUrl, dailymotionUrl, categoryId, subcategoryId, description } = body;

    if (!dailymotionId || !title || !thumbnailUrl || !dailymotionUrl) {
      return NextResponse.json(
        { success: false, message: "Missing required fields" },
        { status: 400 }
      );
    }

    const result = await db
      .insert(videos)
      .values({
        dailymotionId,
        title,
        thumbnailUrl,
        dailymotionUrl,
        categoryId: categoryId || null,
        subcategoryId: subcategoryId || null,
        description: description || null,
      })
      .returning();

    return NextResponse.json({ success: true, video: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Video create error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to create video" },
      { status: 500 }
    );
  }
}
