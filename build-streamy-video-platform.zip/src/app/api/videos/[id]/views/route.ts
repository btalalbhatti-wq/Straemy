import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const videoId = parseInt(id);

    if (isNaN(videoId)) {
      return NextResponse.json(
        { success: false, message: "Invalid video ID" },
        { status: 400 }
      );
    }

    await db
      .update(videos)
      .set({ views: sql`views + 1` })
      .where(eq(videos.id, videoId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("View increment error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to increment views" },
      { status: 500 }
    );
  }
}
