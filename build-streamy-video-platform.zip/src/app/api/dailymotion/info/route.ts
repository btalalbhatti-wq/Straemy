import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get("url");

    if (!url) {
      return NextResponse.json(
        { success: false, message: "URL parameter is required" },
        { status: 400 }
      );
    }

    // Extract Dailymotion video ID from various URL formats
    let videoId = "";

    // Format: https://www.dailymotion.com/video/VIDEO_ID
    const standardMatch = url.match(/dailymotion\.com\/video\/([a-zA-Z0-9]+)/);
    if (standardMatch) {
      videoId = standardMatch[1];
    }

    // Format: https://dai.ly/VIDEO_ID
    const shortMatch = url.match(/dai\.ly\/([a-zA-Z0-9]+)/);
    if (shortMatch) {
      videoId = shortMatch[1];
    }

    // Format: just the video ID
    if (!videoId && /^[a-zA-Z0-9]+$/.test(url.trim())) {
      videoId = url.trim();
    }

    if (!videoId) {
      return NextResponse.json(
        { success: false, message: "Could not extract Dailymotion video ID from URL" },
        { status: 400 }
      );
    }

    // Fetch video info from Dailymotion API
    const apiUrl = `https://api.dailymotion.com/video/${videoId}?fields=title,thumbnail_720_url,thumbnail_1080_url,thumbnail_url,description,duration`;
    
    const response = await fetch(apiUrl, {
      headers: {
        "User-Agent": "Streamy/1.0",
      },
      next: { revalidate: 0 },
    });

    if (!response.ok) {
      return NextResponse.json(
        { success: false, message: "Failed to fetch video info from Dailymotion" },
        { status: 404 }
      );
    }

    const data = await response.json();

    return NextResponse.json({
      success: true,
      videoId,
      title: data.title || "Untitled Video",
      thumbnail: data.thumbnail_1080_url || data.thumbnail_720_url || data.thumbnail_url || "",
      description: data.description || "",
      duration: data.duration || 0,
    });
  } catch (error) {
    console.error("Dailymotion fetch error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to fetch video information" },
      { status: 500 }
    );
  }
}
