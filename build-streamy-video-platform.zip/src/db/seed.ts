import { db } from "@/db";
import { categories, subcategories } from "@/db/schema";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("Seeding categories...");

  const categoryData = [
    { name: "Movies", slug: "movies", icon: "🎬", displayOrder: 1, subs: ["Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Romance", "Thriller", "Documentary"] },
    { name: "TV Shows", slug: "tv-shows", icon: "📺", displayOrder: 2, subs: ["Series", "Reality TV", "Talk Shows", "Animation", "Mini-Series"] },
    { name: "Music", slug: "music", icon: "🎵", displayOrder: 3, subs: ["Pop", "Rock", "Hip-Hop", "Classical", "Electronic", "Jazz", "R&B"] },
    { name: "Gaming", slug: "gaming", icon: "🎮", displayOrder: 4, subs: ["Gameplay", "Walkthroughs", "Esports", "Reviews", "Tips & Tricks"] },
    { name: "Sports", slug: "sports", icon: "⚽", displayOrder: 5, subs: ["Football", "Basketball", "Cricket", "Tennis", "MMA", "Highlights"] },
    { name: "News", slug: "news", icon: "📰", displayOrder: 6, subs: ["World", "Politics", "Technology", "Business", "Science"] },
    { name: "Education", slug: "education", icon: "📚", displayOrder: 7, subs: ["Tutorials", "Lectures", "Coding", "Science", "History"] },
    { name: "Comedy", slug: "comedy", icon: "😂", displayOrder: 8, subs: ["Stand-up", "Sketches", "Pranks", "Parody"] },
    { name: "Travel", slug: "travel", icon: "✈️", displayOrder: 9, subs: ["Adventures", "City Tours", "Food & Culture", "Vlogs"] },
    { name: "Tech", slug: "tech", icon: "💻", displayOrder: 10, subs: ["Reviews", "Unboxing", "Tutorials", "News", "Gadgets"] },
  ];

  for (const cat of categoryData) {
    const existing = await db.select().from(categories).where(eq(categories.slug, cat.slug));
    if (existing.length === 0) {
      const [inserted] = await db.insert(categories).values({
        name: cat.name,
        slug: cat.slug,
        icon: cat.icon,
        displayOrder: cat.displayOrder,
      }).returning();

      for (const subName of cat.subs) {
        const subSlug = cat.slug + "-" + subName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
        await db.insert(subcategories).values({
          name: subName,
          slug: subSlug,
          categoryId: inserted.id,
        });
      }
      console.log(`Seeded: ${cat.name}`);
    } else {
      console.log(`Already exists: ${cat.name}`);
    }
  }

  console.log("Seeding complete!");
}

seed().catch(console.error);
