import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**.dailymotion.com",
      },
      {
        protocol: "https",
        hostname: "**.dmcdn.net",
      },
    ],
  },
};

export default nextConfig;
